package model;

import java.util.List;

import dao.ImageDAO;

public class GetImageListLogic {
    private ImageDAO imageDAO;

    public GetImageListLogic() {
        imageDAO = new ImageDAO();
    }

    public List<Image> execute() {
        List<Image> imageList = imageDAO.findAll();
        return imageList;
    }

	/*public void saveFile(String filename, InputStream fileContent, String contentType) {
		ImageDAO.saveFile(filename, fileContent, contentType);
		
	}*/


}