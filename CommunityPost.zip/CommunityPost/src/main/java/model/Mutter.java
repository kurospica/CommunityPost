package model;

import java.io.Serializable;

public class Mutter implements Serializable {//つぶやきのスコープ
	private int MUTTER_ID;
	private String userName;
	private String text;


	
	public Mutter(String userName, String text) {
	    this.userName = userName;
	    this.text = text;
	  }
	
	public Mutter() {}
	public Mutter(int MUTTER_ID,String userName,String text) {
		this.MUTTER_ID=MUTTER_ID;
		this.userName=userName;
		this.text=text;
	
	}
	public int getId() {return MUTTER_ID;}
	public String getUserName() {return userName;}
	public String getText() {return text;}

	public void setId(int setId) {
		this.MUTTER_ID = setId;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
}
